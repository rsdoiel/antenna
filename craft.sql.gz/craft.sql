PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE channels (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	feed_link TEXT,
	links JSON,
	updated DATETIME,
	published DATETIME,
	authors JSON,
	language TEXT,
	copyright TEXT,
	generator TEXT,
	categories JSON,
	feed_type TEXT,
	feed_version TEXT
);
INSERT INTO channels VALUES('https://blog.lostartpress.com/feed/','Lost Arg Press blog','','https://blog.lostartpress.com/feed/','["https://blog.lostartpress.com","https://blog.lostartpress.com/feed/"]','Tue, 08 Oct 2024 20:50:25 +0000','','','en-US','','https://wordpress.org/?v=6.6.2','','rss','2.0');
CREATE TABLE items (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	enclosures JSON DEFAULT '',
	authors JSON,
	updated DATETIME,
	published DATETIME,
	label TEXT,
	tags JSON DEFAULT '',
	channel TEXT,
	retrieved DATETIME DEFAULT CURRENT_TIMESTAMP,
	status TEXT DEFAULT '',
	dc_ext JSON
);
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/10/jaws/','Jaws','Every chair class Chris teaches seems to develop its own gravitational pull. It&#8217;s inevitable – if you orbit within 50 feet of a class taught by Chris Schwarz you will get sucked in. Now getting sucked into a class can mean many different things: Perhaps it means assisting students taper chair legs by hand until...','','[{"name":"kalevogt"}]','','2024-10-10 10:24:00','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["kalevogt"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/09/the-lost-art-press-food-tour/','The Lost Art Press Food Tour','Note: If you&#8217;re planning on coming to town next month for our Chair Show and Open Day, here are some restaurants to try. There’s a reason Cincinnati is one of the fattest cities in the USA. Megan and I often joke that next year we’re going to flip the script on our classes at the...','','[{"name":"Lost Art Press"}]','','2024-10-09 10:40:00','Lost Arg Press blog','["Woodworking Classes","Lost Art Press Storefront"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/08/flick-that-switch/','Flick That Switch','The following is excerpted from Derek Jones’ new book “Cricket Tables.” Simplicity, necessity and ingenuity are the three key principles for making cricket tables. This traditional three-legged table exists in a variety of forms and woods – no two are the same. So making them follows an organic process – your tools and materials dictate...','','[{"name":"meghanlostartpress"}]','','2024-10-08 07:00:00','Lost Arg Press blog','["Uncategorized","Cricket Tables"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["meghanlostartpress"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/07/new-kits-for-the-hobbit-y-chair/','New Kits for the Hobbit-y Chair','You can now order the carefully chosen wooden parts needed for the Hobbit-y Chair from The Stick Chair Journal No. 2. The kits are $295 and are in red elm, my favorite chairmaking wood. You can order a kit here from Alexander Brothers in Virginia. Shea Alexander and his employees have been supplying me with...','','[{"name":"Lost Art Press"}]','','2024-10-08 00:41:47','Lost Arg Press blog','["The Stick Chair Book","The Stick Chair Journal"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/07/join-us-nov-1-2-at-the-london-woodworking-show/','Join us Nov. 1-2 at the London Woodworking Show','There are just a couple of weeks to go before the 2024 London International Woodworking Festival (LIWF), so Chris I are are busy working on our presentations for the LIWF Bazaar on Friday, Nov. 1 and Saturday, Nov. 2. (Now just where on my computer did I stash those pictures of furniture from Union Village….)...','','[{"name":"fitz"}]','','2024-10-07 10:00:00','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["fitz"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/06/come-see-the-chair-show-on-nov-23/','Come See the Chair Show on Nov. 23','I’ve never shown my work in a gallery. I’ve been asked a few times, but my problem is this: I don’t want to give up 50 percent of the sales price to the gallery. I’d rather skip the glory of cheese and boxed wine in plastic cups and sell my work direct. But gallery shows...','','[{"name":"Lost Art Press"}]','','2024-10-06 12:48:32','Lost Arg Press blog','["The Stick Chair Book","The Stick Chair Journal"]',NULL,'2024-10-11 15:58:05','saved','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/02/new-class-with-jerome-bias/','New Class with Jerome Bias','We’ve added a new class: Build an 18th-century Southern Table with Jerome Bias – it&#8217;s Feb. 17-21, 2025, in our Covington, Kentucky, shop. You can read more about it (and register now) at our ticketing site – but if you’re interested, don’t dally. Space is limited! – Fitz','','[{"name":"fitz"}]','','2024-10-02 16:58:28','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-10-11 15:58:05','read','{"creator":["fitz"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/01/sharp-angles-end-grain/','Sharp Angles & End Grain','This is an excerpt from &#8220;Euclid&#8217;s Door&#8221; by Geo. R Walker and Jim Toplin. The book teaches how to make the tools from &#8220;By Hand and Eye.&#8221; At this point in chapter 7, a miter square that has a 15° tip is being constructed. This fragile corner of the tool has to be taken into...','','[{"name":"meghanlostartpress"}]','','2024-10-01 07:00:00','Lost Arg Press blog','["Uncategorized","Euclid''s Door"]',NULL,'2024-10-11 15:58:05','read','{"creator":["meghanlostartpress"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/30/another-dang-drilling-trick/','Another Dang Drilling Trick','I cut dovetails pretty much the exact same way I did 20 years ago. Same layout, same sawing, same chiseling, same fitting. But when it comes to my chairmaking, things seem to change every day. I’ve been building stick chairs since 2003 (and frame chairs since 1997). So it’s not like I am new to...','','[{"name":"Lost Art Press"}]','','2024-10-01 01:59:16','Lost Arg Press blog','["The Stick Chair Book","The Stick Chair Journal"]',NULL,'2024-10-11 15:58:05','read','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/27/a-how-to-on-filing-new-spokeshaves/','A How-to on Filing New Spokeshaves','Last week I walked into work to a brand-new Veritas spokeshave sitting on my bench. Chris had ordered several for students and kindly ordered an extra for me. (I&#8217;m spoiled, I know.) Grateful, I took a picture of my new tool and posted it to my social media account, not thinking much of it. The...','','[{"name":"kalevogt"}]','','2024-09-27 18:08:27','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-10-11 15:58:05','read','{"creator":["kalevogt"]}');
COMMIT;
