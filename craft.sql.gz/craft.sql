PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE channels (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	feed_link TEXT,
	links JSON,
	updated DATETIME,
	published DATETIME,
	authors JSON,
	language TEXT,
	copyright TEXT,
	generator TEXT,
	categories JSON,
	feed_type TEXT,
	feed_version TEXT
);
INSERT INTO channels VALUES('https://blog.lostartpress.com/feed/','Lost Arg Press blog','','https://blog.lostartpress.com/feed/','["https://blog.lostartpress.com","https://blog.lostartpress.com/feed/"]','Wed, 02 Oct 2024 16:58:46 +0000','','','en-US','','https://wordpress.org/?v=6.6.2','','rss','2.0');
CREATE TABLE items (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	authors JSON,
	updated DATETIME,
	published DATETIME,
	label TEXT,
	tags JSON DEFAULT '',
	channel TEXT,
	retrieved DATETIME DEFAULT CURRENT_TIMESTAMP,
	status TEXT DEFAULT '',
	dc_ext JSON
);
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/27/a-how-to-on-filing-new-spokeshaves/','A How-to on Filing New Spokeshaves','Last week I walked into work to a brand-new Veritas spokeshave sitting on my bench. Chris had ordered several for students and kindly ordered an extra for me. (I&#8217;m spoiled, I know.) Grateful, I took a picture of my new tool and posted it to my social media account, not thinking much of it. The...','[{"name":"kalevogt"}]','','2024-09-27 18:08:27','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-09-28 17:33:24','read','{"creator":["kalevogt"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/25/shaker-stamps/','Shaker Stamps','This summer, the U.S. Postal Service released 12 stamps featuring photographs by Michael Freeman from six different preserved Shaker communities, commemorating the 250th anniversary of the first Shakers arriving in America. Freeman, along with June Sprigg and David Larkin, published “Shaker: Life, Work, and Art,” in 1991. The stamps were designed by Postal Service Art...','[{"name":"Kara Uhl"}]','','2024-09-25 10:00:00','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-09-28 17:33:24','read','{"creator":["Kara Uhl"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/24/what-is-anyone-for/','What is Anyone For?','This is an excerpt from &#8220;Shop Tails: The Animals Who Help Us Make Things Work&#8221; by Nancy R. Hiller. Nancy Hiller’s “Shop Tails,” a companion book of essays to “Making Things Work.” “Shop Tails” is different from “Making Things Work” in that it is structured around the animals that came in and out of Nancy’s...','[{"name":"meghanlostartpress"}]','','2024-09-24 07:00:00','Lost Arg Press blog','["Shop Tails"]',NULL,'2024-09-28 17:33:24','read','{"creator":["meghanlostartpress"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/23/now-shipping-principles-of-design/','Now Shipping: ‘Principles of Design’','A friend recently took a furniture design course taught by a guy I&#8217;ll call Mr. Famous Furniture Maker. During the class there were lectures, field trips to find inspiration, drawing lessons, scale model-making and critiques. &#8220;Well,&#8221; I asked my friend, &#8220;how was the class?&#8221; &#8220;Great,&#8221; he replied. &#8220;Now I know how to design furniture that...','[{"name":"Lost Art Press"}]','','2024-09-23 19:11:02','Lost Arg Press blog','["Principles of Design"]',NULL,'2024-09-28 17:33:24','read','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/23/exeter-hammers-principles-of-design-dados/','Exeter Hammers, ‘Principles of Design’ & Dados','By the end of this week (assuming no more disasters), we should have a clutch of our new Exeter-pattern Furniture-maker&#8217;s Hammers for sale, as well as – finally! – “Principles of Design&#8221; (we thought we&#8217;d have it in June, but we&#8217;ve been bedeviled by cover problems at the bindery). “Principles of Design&#8221; is our title...','[{"name":"fitz"}]','','2024-09-23 10:00:00','Lost Arg Press blog','["Hammers","Dutch Tool Chests","Principles of Design"]',NULL,'2024-09-28 17:33:25','read','{"creator":["fitz"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/22/for-sale-comb-back-stick-chair-in-sycamore-and-oak/','For Sale: Comb-back Stick Chair in Sycamore and Oak','This comb-back stick chair is designed for dining and working at a desk, though its back is leaned back just a bit more to add some comfort. I’m offering it for sale for $1,500 via a random drawing. The price includes crating and shipping to your door anywhere in the lower 48 states of the...','[{"name":"Lost Art Press"}]','','2024-09-22 18:12:35','Lost Arg Press blog','["The Stick Chair Book","The Stick Chair Journal"]',NULL,'2024-09-28 17:33:25','read','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/22/in-30-years-oak-trees-will-have-more-woody-biomass/','In 30 Years, Oak Trees Will Have More Woody Biomass','In an article in “The Conversation,” researchers Rob MacKenzie and Richard Norby, with the Birmingham Institute of Forest Research (BIFoR), shared findings from a recent study published in Nature Climate Change. Their question: How will trees respond to more CO2 in the future? Their laboratory is a forest in Staffordshire, England. Their equipment, tall pipes...','[{"name":"Kara Uhl"}]','','2024-09-22 10:00:00','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-09-28 17:33:25','read','{"creator":["Kara Uhl"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/19/dovetailed-blanket-chest-for-colonial-williamsburg-conference/','Dovetailed Blanket Chest for Colonial Williamsburg Conference','I&#8217;m headed to Virginia this weekend for a few days at Colonial Williamsburg where I&#8217;ll be studying, measuring and taking careful notes on all the details of a late 18th/early 19th-century Virginia blanket chest in the CW collection – a chest I&#8217;ll be replicating for the 27th Annual Working Wood in the 18th Century Conference,...','[{"name":"fitz"}]','','2024-09-19 17:48:19','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-09-28 17:33:25','read','{"creator":["fitz"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/18/stick-chair-journal-no-2-now-shipping/','Stick Chair Journal No. 2 Now Shipping','After an absurd number of delays, The Stick Chair Journal No. 2 is now shipping. The new issue contains complete plans for a Hobbit-esque stick chair, plus lots of photos of original chairs (for inspiration), techniques to help you at the bench and a profile of Welsh chairmaker Gareth Irwin. The new issue is $25....','[{"name":"Lost Art Press"}]','','2024-09-18 18:14:38','Lost Arg Press blog','["The Stick Chair Journal"]',NULL,'2024-09-28 17:33:25','read','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/17/today-i-would-build-some-furniture/','Today I Would Build Some Furniture','The following is excerpted from “The Handcrafted Life of Dick Proenneke,” by Monroe Robinson.&#160; Millions of PBS viewers first met Dick Proenneke through the program “Alone in the Wilderness,” which documents Dick’s 30-year adventure in the Alaskan wilderness. On the shores of Twin Lakes, Dick built his cabin and nearly all of the household objects...','[{"name":"meghanlostartpress"}]','','2024-09-17 07:00:00','Lost Arg Press blog','["Uncategorized","The Handcrafted Life of Dick Proenneke"]',NULL,'2024-09-28 17:33:25','read','{"creator":["meghanlostartpress"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/01/sharp-angles-end-grain/','Sharp Angles & End Grain','This is an excerpt from &#8220;Euclid&#8217;s Door&#8221; by Geo. R Walker and Jim Toplin. The book teaches how to make the tools from &#8220;By Hand and Eye.&#8221; At this point in chapter 7, a meter square that has a 15-degree tip is being constructed. This fragile corner of the tool has to be taken into...','[{"name":"meghanlostartpress"}]','','2024-10-01 07:00:00','Lost Arg Press blog','["Uncategorized","Euclid''s Door"]',NULL,'2024-10-01 12:45:48','saved','{"creator":["meghanlostartpress"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/09/30/another-dang-drilling-trick/','Another Dang Drilling Trick','I cut dovetails pretty much the exact same way I did 20 years ago. Same layout, same sawing, same chiseling, same fitting. But when it comes to my chairmaking, things seem to change every day. I’ve been building stick chairs since 2003 (and frame chairs since 1997). So it’s not like I am new to...','[{"name":"Lost Art Press"}]','','2024-10-01 01:59:16','Lost Arg Press blog','["The Stick Chair Book","The Stick Chair Journal"]',NULL,'2024-10-01 12:45:48','saved','{"creator":["Lost Art Press"]}');
INSERT INTO items VALUES('https://blog.lostartpress.com/2024/10/02/new-class-with-jerome-bias/','New Class with Jerome Bias','We’ve added a new class: Build an 18th-century Southern Table with Jerome Bias – it&#8217;s Feb. 17-21, 2025, in our Covington, Kentucky, shop. You can read more about it (and register now) at our ticketing site – but if you’re interested, don’t dally. Space is limited! – Fitz','[{"name":"fitz"}]','','2024-10-02 16:58:28','Lost Arg Press blog','["Uncategorized"]',NULL,'2024-10-03 15:50:05','saved','{"creator":["fitz"]}');
COMMIT;
