PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE channels (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	feed_link TEXT,
	links JSON,
	updated DATETIME,
	published DATETIME,
	authors JSON,
	language TEXT,
	copyright TEXT,
	generator TEXT,
	categories JSON,
	feed_type TEXT,
	feed_version TEXT
);
CREATE TABLE items (
	link PRIMARY KEY,
	title TEXT,
	description TEXT,
	authors JSON,
	updated DATETIME,
	published DATETIME,
	label TEXT,
	tags JSON DEFAULT '',
	channel TEXT,
	retrieved DATETIME DEFAULT CURRENT_TIMESTAMP,
	status TEXT DEFAULT '',
	dc_ext JSON
);
COMMIT;
